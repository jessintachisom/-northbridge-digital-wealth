const amount=document.getElementById('amount'),term=document.getElementById('term'),amountOut=document.getElementById('amountOut'),termOut=document.getElementById('termOut'),payment=document.getElementById('payment');
function money(n){return '$'+Math.round(n).toLocaleString('en-US')}
function update(){if(!amount||!term)return;const p=+amount.value,n=+term.value,apr=.08,r=apr/12;const m=r===0?p/n:p*r/(1-Math.pow(1+r,-n));amountOut.textContent=money(p);termOut.textContent=n+' months';payment.textContent=money(m)}
amount?.addEventListener('input',update);term?.addEventListener('input',update);update();
