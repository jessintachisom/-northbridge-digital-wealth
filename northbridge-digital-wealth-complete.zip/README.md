# Northbridge Digital Wealth

A clean static website starter for Northbridge Digital Wealth.

## Included
- Public landing page
- Loan calculator
- Demo client login
- Demo dashboard
- Responsive styling
- Clear placeholders for Supabase authentication/database

## Deploy
Upload the entire folder to your GitHub repository, then import that repository into Vercel.

## Supabase
The current UI intentionally does not contain real credentials. Before production use, connect Supabase Auth and database tables, enable RLS, and keep sensitive operations server-side.

## Important
This is a website concept/starter, not a functioning bank, lender, investment adviser, or financial product. Obtain appropriate legal/regulatory review and service-provider integrations before accepting applications or money.
